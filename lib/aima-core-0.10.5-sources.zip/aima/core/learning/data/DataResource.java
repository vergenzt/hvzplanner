package aima.core.learning.data;

public class DataResource {

}
