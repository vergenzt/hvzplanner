package aima.core.logic.fol.parsing.ast;

/**
 * @author Ravi Mohan
 * @author Ciaran O'Reilly
 */
public interface Sentence extends FOLNode {
	Sentence copy();
}
